# Silico Pi session 019f693d-4d9c-7c7b-8bed-99938974de8d

- Timestamp: `2026-07-16T04:44:13.085Z`
- Working directory: `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree`
- Raw snapshot: `remote_silico_cache/archive_extracted/pi-sessions/2026-07-16T04-44-13-085Z_019f693d-4d9c-7c7b-8bed-99938974de8d.jsonl`
- Scope: visible user/assistant content only; thinking, tool calls, and tool results excluded.

## User — 1784177059928

Review triggered: **review_request** (trigger_id: `review-8`)

## Review request

**Summary:** Expert iteration does not internalize the membrane — the pre-projection rejection signal is strong from round 0 and strengthens identically across all three arms. The one membrane-specific effect is that the strict gate induces provenance gaming. The rejection direction is a modest causal handle.

**Main findings.** Across a 3-arm (strict/permissive/no-membrane) × 3-seed × 5-round expert-iteration loop with a small recurrent proposer and the unmodified vendor membrane: (1) the headline hypothesis is not supported — the linearly-decodable "this proposal would be rejected" signal is already strong at round 0 (0.921 at the earliest recurrence step, 0.99 mid-recurrence, floor 0.83) and strengthens only mildly and identically across all arms, so it is generic task learning, not membrane internalization (both pre-registered refutation branches fire); (2) the one clear membrane-specific effect is behavioral and alignment-relevant — the strict gate induces rising provenance mislabeling (claiming env-sound for actually-unsound eliminations, 1.4%→3.3% across rounds in all 3 strict seeds vs flat ~1.8% controls) while ground-truth soundness composition stays flat, i.e. the gate teaches gaming rather than soundness; (3) the always-present rejection direction is a real but modest causal handle on emitted soundness that beats a matched random-direction control.

**Key limitations (stated on the page).** The task is small and fully enumerable, so the round-0 model already saturates the rejection probe — the flat-P2 result means "no additional decodability for the loop to add," not "the membrane provably cannot shape the representation." 3 seeds is a range readout, not a significance claim. Splits are group-disjoint by start state.

Every number on the page was verified against the source CSVs (probe AUROC, mislabel rate, rejection rate, composition, causal sweep). The vendor membrane, env mechanics, and lattice were used unmodified; all new code is in src/.

## Review surface

- Canonical review body: inline body in the review request above
- Surface type: text-only narrative
- Review scope: treat the canonical body as the current result. Do not inspect older `body-*.html` or `preview-*.html` sidecars unless the canonical body directly references them or checkpoint/manifest history names a specific mismatch to resolve.
- Superseded sidecars (not review targets by default): `body-002.html`, `body-004.html`, `body-005.html`, `body-006.html`, `body-007.html`, `preview-002.html`, `preview-004.html`, `preview-005.html`, `preview-006.html`, `preview-007.html`
- Designer routing: skip the designer by default for inline plain-text review bodies. The scientist reviewer should cover narrative/data consistency unless there is a concrete visual surface to audit.

## Experiment manifest

```yaml
experiment: 33
title: "Membrane internalization under expert iteration in the hybrid LDT/TRM gym"
date: "2026-07-16"
status: complete
summary: >
  Mixed/negative result. The pre-projection "would be rejected" signal is strong
  from round 0 and strengthens identically in all three membrane arms (task
  learning, not internalization). The one membrane-specific effect is behavioral:
  the strict gate induces rising provenance mislabeling (1.4%->3.3%) rather than
  genuine soundness. The rejection direction is a real but modest causal handle
  (beats a random-direction control).
data:
  corpus: "$SILICO_EXPERIMENT_ARTIFACTS_DIR/frames/corpus.parquet (4375 exact-labeled rows, group-disjoint by state_id)"
outputs:
  checkpoints: "$SILICO_EXPERIMENT_ARTIFACTS_DIR/checkpoints/ (3 round-0 + 45 loop)"
  activations: "$SILICO_EXPERIMENT_ARTIFACTS_DIR/activations/ (full recurrence traces + labels)"
  probes: "$SILICO_EXPERIMENT_ARTIFACTS_DIR/probes/probe_auroc.parquet, causal_check.parquet, p2_directions.json"
  figdata: "results/figdata/*.csv, specimens.json"
  results_page: "$SILICO_APP_DIR/index.html"
results:
  round0_heldout_acc: [0.897, 0.896, 0.892]
  round0_majority_baseline: 0.668
  p2_step0_strict_r0_to_r5: [0.921, 0.959]
  p2_step0_control_r5: 0.961
  p2_floor: 0.83
  strict_mislabel_r0_to_r5: [0.014, 0.033]
  control_mislabel_r5: 0.018
  strict_rejection_r0_to_r5: [0.680, 0.619]
  env_sound_composition: flat_~0.82
slurm_jobs: [12506, 12517, 12535, 12578]

```

## Source files in experiment dir

- `manifest.yaml` (1.4 KB)
- `figures/causal_check/plot.py` (2.9 KB)
- `figures/mislabel_rate/plot.py` (2.6 KB)
- `figures/p2_auroc_by_round/plot.py` (2.8 KB)
- `figures/p2_cosine_drift/plot.py` (2.4 KB)
- `figures/rejection_composition/plot.py` (2.9 KB)
- `results/assemble_report.py` (20.2 KB)
- `results/build_figures.py` (10.8 KB)
- `scratch/premise_check.py` (2.6 KB)
- `scratch/svg_gen.py` (2.9 KB)
- `scratch/svg_gen7.py` (2.7 KB)
- `src/aggregate.py` (4.5 KB)
- `src/array.sh` (922 B)
- `src/causal.sh` (501 B)
- `src/causal_check.py` (3.4 KB)
- `src/env_labels.py` (4.8 KB)
- `src/frames_gen.py` (3.1 KB)
- `src/probes.py` (6.2 KB)
- `src/rollout.py` (4.2 KB)
- `src/round0_all.sh` (597 B)
- `src/run_loop.py` (11.8 KB)
- `src/smoke.sh` (1.2 KB)
- `src/specimens.py` (2.0 KB)
- `src/train_lib.py` (4.2 KB)
- `src/train_round0.py` (2.2 KB)
- `src/trm.py` (3.0 KB)
- `vendor/HybridTRMLDT/configs/agent_gpt54mini.yaml` (585 B)
- `vendor/HybridTRMLDT/configs/gym.yaml` (301 B)
- `vendor/HybridTRMLDT/environments/hybrid_sequencer_v1/hybrid_sequencer_v1.py` (4.1 KB)
- `vendor/HybridTRMLDT/research_gym/__init__.py` (85 B)
- `vendor/HybridTRMLDT/research_gym/adapters/__init__.py` (636 B)
- `vendor/HybridTRMLDT/research_gym/adapters/airis_das.py` (19.8 KB)
- `vendor/HybridTRMLDT/research_gym/adapters/intellect_logic.py` (2.6 KB)
- `vendor/HybridTRMLDT/research_gym/adapters/metta_adapter.py` (1.8 KB)
- `vendor/HybridTRMLDT/research_gym/adapters/theysing.py` (7.8 KB)
- `vendor/HybridTRMLDT/research_gym/adapters/verifiers_v1.py` (3.7 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/__init__.py` (272 B)
- `vendor/HybridTRMLDT/research_gym/benchmarks/arc_bench.py` (10.9 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/control_harness_bench.py` (15.1 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/routing_bench.py` (11.8 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/sequencer_control_bench.py` (43.4 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/storyworld_architecture_bench.py` (7.5 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/storyworld_bench.py` (6.8 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/sudoku_bench.py` (6.6 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/theysing_native_bench.py` (13.4 KB)
- `vendor/HybridTRMLDT/research_gym/benchmarks/training_review_bench.py` (8.2 KB)
- `vendor/HybridTRMLDT/research_gym/core/__init__.py` (988 B)
- `vendor/HybridTRMLDT/research_gym/core/frames.py` (3.1 KB)
- `vendor/HybridTRMLDT/research_gym/core/hybrid.py` (8.6 KB)
- `vendor/HybridTRMLDT/research_gym/core/lattice.py` (2.7 KB)
- `vendor/HybridTRMLDT/research_gym/core/metta_frames.py` (6.4 KB)
- `vendor/HybridTRMLDT/research_gym/core/training_review.py` (21.5 KB)
- `vendor/HybridTRMLDT/research_gym/core/typed_soundness.py` (863 B)
- `vendor/HybridTRMLDT/research_gym/discovery/__init__.py` (75 B)
- `vendor/HybridTRMLDT/research_gym/discovery/application_map.py` (6.4 KB)
- `vendor/HybridTRMLDT/research_gym/discovery/project_inventory.py` (6.5 KB)
- `vendor/HybridTRMLDT/research_gym/envs/__init__.py` (288 B)
- `vendor/HybridTRMLDT/research_gym/envs/arc_tasks.py` (5.5 KB)
- `vendor/HybridTRMLDT/research_gym/envs/control_tasks.py` (12.2 KB)
- `vendor/HybridTRMLDT/research_gym/envs/coupled_storyworld.py` (6.8 KB)
- `vendor/HybridTRMLDT/research_gym/envs/metta_synthetic.py` (7.0 KB)
- `vendor/HybridTRMLDT/research_gym/envs/routing.py` (2.8 KB)
- `vendor/HybridTRMLDT/research_gym/envs/sudoku.py` (6.0 KB)
- `vendor/HybridTRMLDT/research_gym/eval/__init__.py` (300 B)
- `vendor/HybridTRMLDT/research_gym/eval/baselines.py` (3.9 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/__init__.py` (44 B)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_airis_das_bridge.py` (5.9 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_arc1.py` (966 B)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_arc2.py` (1.1 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_control_harnesses.py` (7.1 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_routing.py` (4.2 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_sequencer_control.py` (8.1 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_storyworld.py` (2.6 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_storyworld_architectures.py` (3.1 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_sudoku.py` (978 B)
- `vendor/HybridTRMLDT/research_gym/scripts/bench_theysing_native.py` (2.1 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/compare_benchmarks.py` (14.2 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/eval_frames.py` (1.2 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/eval_symbolic.py` (1.4 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/export_sft_dataset.py` (1.9 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/generate_frames.py` (1.6 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/generate_metta_frames.py` (1.3 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/inspect_intellect_logic.py` (1.9 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/review_model_training.py` (4.1 KB)
- `vendor/HybridTRMLDT/research_gym/scripts/write_agent_tasks.py` (3.1 KB)
- `vendor/HybridTRMLDT/scripts/smoke_airis_das_bridge.py` (4.2 KB)
- `vendor/HybridTRMLDT/scripts/smoke_verifiers_v1.py` (1.2 KB)
- `vendor/HybridTRMLDT/tests/test_airis_das_adapter.py` (6.1 KB)
- `vendor/HybridTRMLDT/tests/test_arc1_bench.py` (1.7 KB)
- `vendor/HybridTRMLDT/tests/test_arc2_bench.py` (1.6 KB)
- `vendor/HybridTRMLDT/tests/test_compare_benchmarks.py` (1.9 KB)
- `vendor/HybridTRMLDT/tests/test_control_harness_bench.py` (1.3 KB)
- `vendor/HybridTRMLDT/tests/test_eval_baselines.py` (2.9 KB)
- `vendor/HybridTRMLDT/tests/test_frame_schema.py` (2.1 KB)
- `vendor/HybridTRMLDT/tests/test_hybrid_membrane.py` (3.7 KB)
- `vendor/HybridTRMLDT/tests/test_intellect_logic_adapter.py` (1.2 KB)
- `vendor/HybridTRMLDT/tests/test_metta_adapter.py` (1.6 KB)
- `vendor/HybridTRMLDT/tests/test_metta_frames.py` (2.0 KB)
- `vendor/HybridTRMLDT/tests/test_metta_synthetic.py` (2.3 KB)
- `vendor/HybridTRMLDT/tests/test_project_inventory.py` (1.3 KB)
- ... (truncated)

## Artifacts

- `/mnt/data/artifacts/silico/experiments/_flat/exp_01kxm8pz75fbe9e2a4vx27crr6/probes/causal_check.parquet` (eval_results, 5.0 KB): causal_check.parquet
- `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree/experiments/experiment-33/results/figdata/behavioral.csv` (eval_results, 13.1 KB): behavioral.csv
- `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree/experiments/experiment-33/results/figdata/probe_headline.csv` (eval_results, 12.8 KB): probe_headline.csv
- `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree/experiments/experiment-33/results/figdata/probe_allsteps.csv` (eval_results, 38.6 KB): probe_allsteps.csv
- `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree/experiments/experiment-33/results/figdata/arm_summary.csv` (eval_results, 1.2 KB): arm_summary.csv
- `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree/slurm-logs/slurm-12517.out` (file, 7.8 KB): round-0 log (job 12517)
- `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree/slurm-logs/slurm-12506.out` (file, 1.3 KB): smoke log (job 12506)
- `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/worktree/experiments/experiment-33/scratch/premise_check.py` (file, 2.6 KB): premise_check.py
- `/mnt/data/artifacts/silico/experiments/_flat/exp_01kxm8pz75fbe9e2a4vx27crr6/frames/manifest.json` (dataset, 456 B): corpus manifest

## Experiment history (recent checkpoints)

- **Checkpoint 4** (decision_taken): Probing the step just before emission saturated P2 at 0.999, leaving no room to show strengthening. Switched to dumping the full recurrence trace and reading the headline P2 at an early step, keeping the late step + proposal logits as skylines.
- **Checkpoint 5** (progress): All 3 shared per-seed round-0 checkpoints clear the precondition with large margin (~0.90 held-out accuracy). The full 3-arm × 3-seed × 5-round loop array is submitted.
- **Checkpoint 6** (progress): Across all 45 checkpoints, the pre-projection rejection signal is strong from round 0 and strengthens identically in all three arms — generic training, not membrane internalization. The one membrane-specific effect is negative: the strict gate raises provenance mislabeling.
- **Checkpoint 7** (progress): Adding the P2 direction to the latent makes emitted proposals less sound (more unsound, less abstain); ablating it makes them more conservative. The effect is monotone and direction-specific — a matched random direction does nothing — but small even at large scale.
- **Checkpoint 8** (review_request): Expert iteration does not internalize the membrane — the pre-projection rejection signal is strong from round 0 and strengthens identically across all three arms. The one membrane-specific effect is that the strict gate induces provenance gaming. The rejection direction is a modest causal handle.

Record your findings by calling the `write_critic_findings` tool with the full findings object (verdict, summary, triage, findings list). Do NOT write the file via Bash. The tool writes to `/mnt/data/shared/silico/experiments/exp_01kxm8pz75fbe9e2a4vx27crr6/checkpoints/critic-review-review-8.json` and delivers the verdict to the worker in one step.

## Assistant — 1784177060184

I'll dispatch the code and scientist reviewers in parallel. This is an inline plain-text body with no HTML result page, so designer review is skipped per routing rules.

## Assistant — 1784177093596

The subagent tool isn't available under that name. Let me check available tools.

## Assistant — 1784177096467

Subagents aren't available in this runtime. I'll do a focused review myself with light tools, respecting compute discipline (no heavy ops; small CSVs only).

## Assistant — 1784177127393

The 875 nonterminal states (7×5×5×5) is the genuine full enumeration, and the corpus stores distinct rows once. The "4375 vs 200k" is not a narrowing. Now let me verify the headline numbers against the CSVs and check the provenance/entropy claims.

## Assistant — 1784177140296

Two arms (permissive and no_membrane) show byte-identical results across every seed, round, and metric. Let me check how arms map to membrane policy in the loop.

## Assistant — 1784177178871

The permissive/no_membrane identity is important. Let me confirm by reading the vendor membrane logic.

## Assistant — 1784177233121

I've confirmed the key issue by tracing the membrane logic. Let me record my findings.

The permissive arm produces byte-identical results to the no-membrane control across every seed, round, and metric (e.g. `arm_summary.csv`: both arms show reject_rmax 0.6353, mislabel 0.0201 for seed 0, identical to 16 decimals throughout `probe_headline.csv`). Tracing the code: permissive = `MembranePolicy(allow_model_sound=True, allow_experience_sound=True)` accepts all three provenance claims the model emits, so its only binding rejections are the lattice refinement/bottom guards, which the no-membrane `certify` also enforces. The two arms are the same condition in practice. Everything else in the analysis is sound and well-calibrated (full 875-state enumeration is genuine, splits are group-disjoint, the probe saturation limitation is stated honestly, the strict-gate provenance-gaming effect is consistent across all 3 seeds, entropy does not collapse).
