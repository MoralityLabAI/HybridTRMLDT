# MCP-07 Portable Evidence Packet (Independent Review)

- Experiment ID: `MCP-07-ADAPTIVE-GEOMETRY-V1`
- Frozen protocol commit: `0620aff37dff5b8593f52686f4e7daa37748e651`
- Frozen `manifest.json` SHA-256: `4ac105df37ec9328e8b4088a1536396c5f5b3b7af62a7720a3a6c9be9c319b3b`

## Contents
- `REGISTERED_MCP07_REPORT.md` — Full results report with PASS/FAIL gates, paired bootstrap CIs, capacity scaling (16K-128K), corruption sweep, ablations, distribution shift, and separate native Storyworld track.
- `MECHANISTIC_REPORT.md` — Router telemetry, slow/fast linear probes, switch transition matrix, and all 5 paired causal interventions.
- `SPEC.md` & `manifest.json` — Formal specification and frozen protocol manifest.
- `registered/summary.json` & `registered/summary_metrics.json` — Complete 34,560-cell evaluation summary and compact gate/telemetry summary.
- `registered/ablations.json` — Supervision, communication, 116K scaling, and 80/20->20/80 distribution-shift results.
- `registered/native_storyworld.json` — Separate MCP-05 witness replay and witness-withheld independent route discovery receipts.
- `registered/mechanistic.json` — Complete mechanistic probing and causal intervention JSON.
- `registered/roots.jsonl.gz` — All 3,317,760 per-root receipts (compact gzipped JSONL).
- `registered/failed_episodes.jsonl.gz` — Complete log of all failed episodes.
- `registered/checkpoints/*.pt` — All 36 frozen 16K PyTorch checkpoints (`24` core + `9` ablations + `3` distribution-shift).
- `registered/checkpoints_sha256.json` & `PACKET_MANIFEST.json` — Complete SHA-256 integrity manifests.
