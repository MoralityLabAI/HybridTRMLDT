# MCP-08 Portable Evidence Packet (Independent Review)

- **Experiment ID**: `MCP-08-VERIFIER-RECURSIVE-SEARCH-V1`
- **Branch**: `gym/mcp08-verifier-search`
- **Parent MCP-07 Commit (Preserved Untouched)**: `e0bf57f760890856dbc87c26cefc5065a70f18de`
- **Frozen Protocol Commit (Pre-Sealed Evaluation)**: `791a8d0a688a869e5dc2795f26da096cac14f15b`
- **Frozen `manifest.json` SHA-256**: `cc5d2028d0cf4fe664ed185467e5af75fb0a7a086489147488d84dd3065e746d`

## Gate Summary (Sealed Evaluation)
- **Gate 1 (Long-Horizon Native Storyworld, 32K, c=10%, 5-50 decisions, n=144)**: **PASS** (`50.00%` vs `mcp07_orig` `2.08%`, `beam_search` `18.06%`, `bounded_symbolic` `6.94%`, `greedy_planning` `1.39%`, `uniform_retries` `1.39%`; `39.58%` on 256K Storyworld)
- **Gate 2 (16K -> 256K Synthetic Extrapolation, c=10%, n=1,152)**: **FAIL** (`64.1%` vs `det_router` `50.1%` [+13.98 pp], `uniform_retries` `57.1%` [+6.94 pp], `mcp07_orig` `59.9%` [+4.17 pp, statistically positive but below +10.0 pp threshold])
- **Gate 3 (Calibration & Hierarchical Compute Allocation, c=10%)**: **PASS** (`256K` AUROC=`0.7030`, ECE=`0.0688`; Storyworld read reduction vs fixed `uniform_deep` = `-55.73%` with `+2.78 pp` higher completion; `256K` read reduction = `-25.97%`)
- **Gate 4 (Cross-Domain Slow-State Transfer: Storyworld / Canvas / Lean)**: **PASS** (zero-shot off-diagonal progress `R^2 = +0.6228`, `r = +0.8174`, beating fast state `h_t` `+0.5355` and null `-0.2257`; 6-pair activation patching `delta P(halt) = +10.3 to +23.1 pp`)
- **Compute Gate**: **PASS** (`54,511` active parameters, `545.77 MiB` peak RSS, CPU-only)

## Contents
- `REGISTERED_MCP08_REPORT.md`: Complete quantitative evaluation report, cost breakdown, and preserved negative/null findings.
- `MECHANISTIC_REPORT.md`: 3x3 slow-vs-fast cross-domain linear probes, 6-pair activation patching, and trained-from-scratch vs inference-time lesion analysis.
- `SPEC.md`, `manifest.json`: Formal specification and pre-evaluation frozen protocol manifest.
- `registered/`: Full JSON summaries, SHA-256 checkpoint manifest, `episodes.jsonl.gz` (61,344 rows), `failed_episodes.jsonl.gz` (23,118 preserved failures), and all 18 trained `.pt` checkpoints (3 seeds x full + 5 scratch ablations).
- `PACKET_MANIFEST.json`: File-by-file SHA-256 and byte-size inventory of this archive.
